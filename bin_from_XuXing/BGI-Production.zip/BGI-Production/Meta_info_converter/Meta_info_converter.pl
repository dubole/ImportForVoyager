#!/usr/bin/perl -w
#Author: Yuanyuan Ma
#Email:mayuanyuan@genomics.org.cn
#File Name:
#Description:
#
#Edit History:
#2014-05-08 09:36:00  File created.
use strict;  
use warnings; 
use Getopt::Long qw/GetOptions/;
my $usage=<<'USAGE';
Discription:
	Meta_info_converter.pl
History
	Author:Yuanyuan MA,mayuanyuan@genomics.cn
	Version:0.1,   Datt:2014-05-07
Usage:
	perl Meta_info_converter.pl [Options]
		 -i FILE Input File, 	like meta.xls
		 -c FILE Config File	[config.txt]
		 -l FILE Library File	[lib.txt]
Example
	perl Meta_info_converter.pl -i meta.xls/meta.xlsx -c config.txt -l lib.txt -o out.txt
USAGE
my ($input,$config,$lib,$output,$help,$worksheet,$flag);
$flag = 0;

GetOptions(
	'i=s'   => \$input,
	'c=s'  => \$config,
	'l=s'    => \$lib,
	'help|?' => \$help
);

die "$usage\n" if($help || !$input || !$config || !$lib);
our (%config,%lib);
require $config;
require $lib;

my @colnum=(0..3,6,8,10,17,18,20,29..35,37,38,39);
my $postfix = (split /\./, $input)[-1];
#print $postfix."\n";

my $caseDataRoot = $config{caseDataRoot};

print "case path $caseDataRoot\n";

unless (-d $caseDataRoot) {
	mkdir ($caseDataRoot);
}

if($postfix eq "xls"){
	($worksheet,$flag) = read_xls($input);
}elsif($postfix eq "xlsx"){
	($worksheet,$flag) = read_xlsx($input);	
}else{
	exit 1;	
}

& updateLIB ($lib, \%lib);


######################################
#			subroutines				v#
######################################

sub updateLIB () {
	my ($lib, $lib_r) = @_;

	open (LIB, ">$lib.tmp")  || die;
	
	my $lib_content = `cat $lib`;
	my $site = $config{Site};
	
	$lib_content =~ s/\'$site\'\s*\=\>\s*\d+/\'$site\' => $lib_r->{siteCaseCounter}->{$site}/g;
	
	
	print LIB "$lib_content";
	
	close LIB;
	
	system ("mv $lib.tmp  $lib");
}


sub read_xls{
	use Spreadsheet::ParseExcel;  
	use Spreadsheet::ParseExcel::FmtUnicode;  
	use Spreadsheet::ParseExcel::FmtDefault;  

	my $excel = shift;
	my $parser= Spreadsheet::ParseExcel->new();  
	my $fmt = Spreadsheet::ParseExcel::FmtUnicode->new(Unicode_Map => 'gb2312');  
	my $workbook = $parser->Parse($excel, $fmt);  
	for my $worksheet ($workbook->worksheets()) {
		my ($row_min, $row_max) = $worksheet->row_range();
		for my $row ($row_min+1.. $row_max) {
			my $noid = $row; 
			my @data=();
			my $testIndication="";
			for my $col (@colnum){
				my $cell = $worksheet-> get_cell($row, $col);
				my $content = $cell->Value();
				if($col==0){
					$content=get_id($noid);
				}
				push @data,$content;
				if($col==17){
					$testIndication =$content;
				}elsif($col==18){
					$content=join("\/","[".pop(@data)."]", "[".$testIndication)."]";
					push @data,$content;
				}
			}
			
			&printJSON(\@data);
		}
	}
	
	return $worksheet,$flag;
}

sub read_xlsx{
	use Spreadsheet::XLSX;
	use Encode; 
	my $input = shift;
	my $excel = Spreadsheet::XLSX -> new ($input); 		 
	foreach my $worksheet (@{$excel -> {Worksheet}}) {
		$worksheet -> {MaxRow} ||= $worksheet -> {MinRow};
		
		my @colName = ();
		foreach my $row ($worksheet -> {MinRow}.. $worksheet -> {MaxRow}) {
			my $noid = $row;
			my @data=();
			for my $col (@colnum) {
				my $cell = $worksheet -> {Cells} [$row] [$col];
				#my $content = encode("gbk", decode("utf8", $cell->{Val})); 
				my $content = $cell->{Val}; 
				
				
				if(! defined $content){
					$content = "";
				}
				if ($row == $worksheet -> {MinRow}) {
					$content =~ s/\d+$//g;
					push @colName,$content;
				} else {
					push @data, $content;
				}
			}
			if ($row > $worksheet -> {MinRow}) {
				&printJSON(\@data, \@colName);
			}
		}
	}
	$flag = 1;
	return $worksheet,$flag;
}

sub printJSON() {
	my ($data_r, $col_name_r) = @_;
	
	my ($caseID, $result) = get_json($data_r, $col_name_r);

	unless (-d "$caseDataRoot/$caseID") {
		mkdir ("$caseDataRoot/$caseID");
	}

	open JSON, ">$caseDataRoot/$caseID/$caseID.json" or die $!;
	print JSON $result,"\n";
	close JSON;


	open FLAG, ">$caseDataRoot/$caseID/finish.flag" or die $!;
	print FLAG "finished\n";
	close FLAG;
}


#convert to json format file 
sub get_json{
	my ($data_r, $col_name_r) = @_;
	my @data = @$data_r;
	my @col_name = @$col_name_r;
	my @careTeamGroups = split(/;/, $config{careTeamGroups});
	my @interpretatonGro = split(/,/, $careTeamGroups[0]);
	my @reviewGro = split(/,/, $careTeamGroups[1]);
	my @careTeamInstitutions = split(/,/, $config{careTeamInstitutions});
	my @careTeamMembers = split(/,/, $config{careTeamMembers});	
	my $year = $config{Year};
	my $site = $config{Site};
	my $institution = $config{Institution};

	#Ã‘Ã¹Â±Â¾ÃÃ…ÃÂ¢
	my $sampleID = $data[2];
	my $sample=
	"	\"sample\": [\n".
	"		{\n".
	"			\"name\": \"$sampleID\",\n".           					#样品ID
	"			\"drawDate\": \"".&dateformat($data[10])."\",\n".       	#时间格式必须为YYYY-MM-DDT00:00:00Z
	"			\"type\": \"".&get_sampleType($data[1])."\",\n".           #样品Type必须为英文
	"			\"crossRefs\": [\n".
					&getCrossReference($col_name[3], $data[3])."\n". #原样品编号
	"			]\n".
	"		}\n".
	"	]\n";

	my $proband = 
	"	\"proband\": {\n".
 	"		\"name\": \"PB$sampleID\",\n".            	# ProbandID PB+样品ID
	"		\"dateOfBirth\": \"".&dateformat($data[6])."\",\n".       	#时间格式必须为YYYY-MM-DDT00:00:00Z
	"		\"gender\": \"".&getGender($data[4])."\",\n".				#必须为英文 Male or Female
	"		\"ethnicities\": [\n".
	"			{\n".
	"				\"name\": \"Chinese\"\n".   		#ÃƒÃ±Ã—Ã¥8
	"			}\n".
	"		  ],\n".
	"		\"crossRefs\": [\n".
				&getCrossReference("Original MedID", "PB$sampleID-1")."\n".	#Ã"Â­ÃŠÂ¼Â²Â¡Ã€ÃºÂºÃ…Â£ÂºÃÃÂ±Ã­Ã–ÃÃŽÃžÂ£Â¬Â½Â¨Ã’Ã©ÃŒÃ­Â¼Ã"Â£Â¬Ã"ÃÃ‰Ã¨Ã–ÃƒÃŽÂªÂ¿Ã•
	"		 ]\n".
	"	},\n";

	#CaseÃÃ…ÃÂ¢
	my $caseID = &getCaseID($year, $site, \%lib);
	my $interpretor = &getInterpretationOwner ($year, $site, \%lib);
	my $case =
	"	\"case\": {\n". 
	"		\"name\": \"". $caseID. "\",\n".   			#Â¶Â¨ÂµÂ¥Â±Ã ÂºÃ…0
	"		\"status\": \"pending\",\n".  			#Â²Ã‰Ã"ÃƒÃˆÂ±ÃŠÂ¡Ã–Âµ
	"		\"additionalPhenotypicInformation\": \"".
	&print_content("", $col_name[16], $data[16]).
	&print_content("", $col_name[12], $data[12]).
	&print_content("", $col_name[7], $data[7]).
	"\",\n".
	"		\"familyHistory\": \"".
	&print_content("", $col_name[11], $data[11]).
	&print_content("", $col_name[13], $data[13]).
	&print_content("", $col_name[14], $data[14]).
	&print_content("", $col_name[15], $data[15]).
	"\",\n".
	"		\"primaryDisease\": \"$data[17]\",\n".  					#初步诊断
	"		\"testIndication\": \"\[$data[8]\]\/\[$data[7]\]\",\n".   	#检测类型,诊断
	"		\"selectedTest\": {\n".
	"			\"name\": \"$data[18]\",\n".   							#检测疾病种类
	"			\"id\": \"$data[19]\"\n".   							#检测疾病种类
	"		},\n".
	"		\"interpretationApprover\": {\n".
	"			\"email\": \"". &getInterpretationApprover ($year, $site, \%lib, $interpretor). "\"\n".   				#lib.txt: approverEmail
	"		},\n".
	"		\n".
	"		\"interpretationOwner\": {\n".
	"			\"email\": \"". $interpretor. "\"\n".   				#lib.txt: interpretorEmail
	"		},\n".
	"		\"careTeamGroups\": ".&getCareTeamGroups (\%config, "		").",\n".
	"		\"careTeamInstitutions\": ".&getCareTeamInstitutions (\%config, "		").",\n".
	"		\"careTeamMembers\": ".&getCareTeamMembers (\%config, "		").",\n".
	"		\"crossRefs\": [\n".
				&getCrossReference ($col_name[0], &get_id($data[0])).",\n".            			#Â¶Â¨ÂµÂ¥Â±Ã ÂºÃ…0
				&getCrossReference ($col_name[10], $data[10])."\n".            			#Â¶Â¨ÂµÂ¥Â±Ã ÂºÃ…0
	"		],\n".
	"		\"attachments\": ". &attachOrderForm($sampleID, $caseID, "		")."\n".
	"	},\n";



	my $result=join("","{\n",$case,$proband,$sample,"}");
	return ($caseID, $result);
}

sub get_sampleType (){
		my ($sampleType) = @_;

		$sampleType =~ s/WBLOOD/Whole Blood/;

		return $sampleType;
}

sub dateformat (){
	my ($date) = @_;

	$date =~ s/\//\-/g;
	$date =~ s/\./\-/g;

	#if ($date =~ /^\d\d\d\d-\d\d-\d\d$/) {
	#	die ("Error! $date  时间格式必须为YYYY-MM-DD。");
	#}

	return "$date"."T00:00:00Z";
}

sub print_content (){
        my ($spacing, $str, $content) = @_;

        my $rtn = "$spacing$str:\\n$spacing$content\\n$spacing\\n";
        if (($content eq "") || ($content eq "无") || ($content eq "null")) {
                $rtn = "";
        } 
        return $rtn;
}

sub get_id (){
	my $id = shift;
	my $year = substr((split /\s+/,`date`)[-1], 2, 2);
	my $diflen = 8 - length($id);
	my $tmp="";
	for(1..$diflen){
		$tmp.="0";	
	}
	$id = $year.$tmp.$id;
	return "$id";
}

sub getCaseID (){
	my ($year, $site, $lib_r) = @_;

	my $cnt = ++$lib_r->{"siteCaseCounter"}->{$site} ;

	my $rtn =  $year.$site.sprintf("%08d", $cnt);

	return $rtn;
}

#use defined InterpretationOver or automatically assign
sub getInterpretationOwner (){
	my ($year, $site, $lib_r) = @_;

	my $cnt = $lib_r->{"siteCaseCounter"}->{$site} ;
	
	if (exists $config{InterpretationOwner}) {
		my %seen; 
		$seen{$_}++ for @{$lib_r->{InterpretationOwner}};
	    if (exists $seen{$config{InterpretationOwner}}) {
	    	return ($config{InterpretationOwner});
	    } else {
	    	die ("Error, the email is not in the list of InterpretationOwners.
	    		\n");
	    }
    } else {
    	my $size = @{$lib_r->{InterpretationOwner}};

    	return $lib_r->{InterpretationOwner}->[$cnt % $size];
    }
}

#use defined InterpretationApprover or automatically assign
sub getInterpretationApprover (){
	my ($year, $site, $lib_r, $interpretor) = @_;

	my $cnt = $lib_r->{"siteCaseCounter"}->{$site} ;
	
	if (exists $config{InterpretationApprover}) {
		my %seen; 
		$seen{$_}++ for @{$lib_r->{InterpretationApprover}};
	    if (exists $seen{$config{InterpretationApprover}}) {
	    	return ($config{InterpretationApprover});
	    } else {
	    	die ("Error, the email is not in the list of InterpretationApprovers.
	    		\n");
	    }
    } else {
    	my $size = @{$lib_r->{InterpretationApprover}};

    	if ($interpretor ne $lib_r->{InterpretationApprover}->[$cnt % $size]) {
		return $lib_r->{InterpretationApprover}->[$cnt % $size];
	} else {
		if ($cnt % $size == 0)  {
			return $lib_r->{InterpretationApprover}->[1];
		} else {
			return $lib_r->{InterpretationApprover}->[$cnt % $size - 1];
		}
	}
    }
}

sub getCareTeamGroups () {
	my ($cfg_r, $spacing) = @_;
	my @careTeamGroups = split(/;/, $cfg_r->{careTeamGroups});

	my $rtn = ''; 
	foreach my $grp (@careTeamGroups) {
		my @grp_itm = split(/,/, $grp);
		$rtn.= 
	"			{\n".	
	"				\"group\": {\n".                         				#config.txt: careTeamGroups
	"					\"name\": \"$grp_itm[0]\"\n".
	"				},\n".
	"				\"profile\": {\n".
	"					\"name\": \"$grp_itm[1]\"\n".
	"				},\n".
	"				\"role\": \"$grp_itm[2]\"\n".
	"			},\n";

	}

	$rtn =~ s/,$//g;

	return &printResult($rtn, $spacing);
}


sub getCareTeamInstitutions () {
	my ($cfg_r, $spacing) = @_;
	my @careTeamInstitutions = split(/;/, $cfg_r->{careTeamInstitutions});

	my $rtn = '';                         				#config.txt: careTeamGroups
 
	foreach my $grp (@careTeamInstitutions) {
		my @grp_itm = split(/,/, $grp);
		$rtn.= 
	"			{\n".	
	"				\"institution\": {\n".
	"					\"name\": \"$grp_itm[0]\"\n".
	"				},\n".
	"				\"profile\": {\n".
	"					\"name\": \"$grp_itm[1]\"\n".
	"				},\n".
	"				\"role\": \"$grp_itm[2]\"\n".
	"			},\n";
	}

	$rtn =~ s/,$//g;

	return &printResult($rtn, $spacing);
}

sub getCareTeamMembers () {
	my ($cfg_r, $spacing) = @_;
	my @careTeamMembers = split(/;/, $cfg_r->{careTeamMembers});

	my $rtn = '';                         				#config.txt: careTeamGroups
 
	foreach my $grp (@careTeamMembers) {
		my @grp_itm = split(/,/, $grp);
		$rtn.= 
	"			{\n".	
	"				\"profile\": {\n".
	"					\"name\": \"$grp_itm[0]\"\n".
	"				},\n".
	"				\"person\": {\n".
	"					\"email\": \"$grp_itm[1]\"\n".
	"				},\n".
	"				\"role\": \"$grp_itm[2]\"\n".
	"			},\n";
	}

	$rtn =~ s/,$//g;

	return &printResult($rtn, $spacing);
}

sub attachOrderForm (){
	my ($sampleID, $caseID, $spacing) = @_;
	my $rtn = '';

	my $sampleOrderForm = "$config{sampleDataRoot}/$sampleID/sampleOrderForm_$sampleID\.pdf";
	print "$sampleOrderForm\n";
	if (-e $sampleOrderForm) {
		unless (-d "$caseDataRoot/$caseID") {
			mkdir ("$caseDataRoot/$caseID");
		}

		system ("cp $sampleOrderForm $config{caseDataRoot}/$caseID/$caseID\_OrderForm.pdf");

		my $url = "$config{s3Bucket}/cases/$caseID/$caseID\_OrderForm.pdf";
		$rtn.= &getAttachments("送检单", "送检单", $url); 
	} 
	
	return &printResult($rtn, $spacing);
}

sub printResult () {
	my ($rtn, $spacing) = @_;

	if ($rtn eq '') {
                return "[]";
        } esle {
                return "[\n$rtn$spacing]";
        }
}

sub getGender () {
        my ($gender) = @_;

        if ($gender eq '男') {
                $gender = 'Male';
        } elsif ($gender eq '女') {
                $gender = 'Female';
        } elsif ($gender eq '其他') {
                $gender = 'Other';
        } else {
                $gender = uc(substr($gender, 0, 1)).lc(substr($gender, 1));
        }

        if (($gender ne 'Male') && ($gender ne 'Female') && ($gender ne 'Other')) {
                die ("Error! Gender of a proband can ONLY be Male, Female, Other.");
        }

        return $gender;
}

sub getAttachments (){

	my ($description, $name, $url) = @_;
	my $rtn = '';

	$rtn.= "		{\n";
	$rtn.= "			\"description\": \"$description\",\n";
	$rtn.= "			\"name\": \"$name\",\n";
	$rtn.= "			\"url\": \"$url\"\n";
	$rtn.= "		}\n";

	$rtn;
}

sub getCrossReference () {
	my ($name, $value) = @_;
	
	my $rtn = '';

	if ($value ne '') {
		$rtn =
		"			{\n".
		"				\"name\": \"$name\",\n".
		"				\"value\": \"$value\"\n".            			#Â¶Â¨ÂµÂ¥Â±Ã ÂºÃ…0
		"			}";
	}

	return $rtn;
}

