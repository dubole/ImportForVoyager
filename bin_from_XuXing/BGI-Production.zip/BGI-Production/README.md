Tools for deploying on the production environment.

Meta_info_Converter: 
        Input: sample/case information in xlsx or xls format
        Output: json file for each case.


~/BGI-Production/Meta_info_converter/Meta_info_converter.pl -i ~/BGI-Production/Meta_info_converter/test/meta_json-test3.xlsx -c ~/BGI-Production/Meta_info_converter/conf/example.conf -l ~/BGI-Production/Meta_info_converter/conf/lib.txt